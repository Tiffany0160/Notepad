// Function to save the note as a text file
function saveNote() {
    const noteContent = document.getElementById("notepad").value;
    
    // Create a blob from the note content
    const blob = new Blob([noteContent], { type: 'text/plain' });
    
    // Create a download link for the file
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "note.txt"; // Name of the saved file
    link.click(); // Trigger the download
}
